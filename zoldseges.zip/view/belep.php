<form action="index.php?page=belep&action=login" method="POST">
    <fieldset>
        <legend>Bejelentkezés</legend>
        <label for="user">Felhasználónév</label>
        <input type="text" id="user" name="user">
        <label for="pass">Jelszó</label>
        <input type="password" id="pass" name="pass">
        <input type="submit" value="Belépés">
    </fieldset>
</form>