<form action="index.php?page=hozzaad" method="POST">
    <fieldset>
        <legend>Hozzáad</legend>
        <label for="name">Termék neve</label>
        <input type="text" id="name" name="name">
        <input type="submit" value="Hozzáad">
    </fieldset>
</form>