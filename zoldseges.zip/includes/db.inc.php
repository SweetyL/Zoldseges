<?php
$servername = "localhost";
$username = "zoldseges";
$password = "KD[6m5MnXOTBbXo4";
$dbname = "zoldseges";

$conn = new mysqli($servername, $username, $password, $dbname);

?>
